import java.io.*;
import java.net.Socket;
import java.util.StringTokenizer;


public class Client {

    private Socket socket = null;
    private BufferedReader reader = null;
    private BufferedWriter writer = null;
    private static boolean debug = false;
    private String host;//连接主机
    private String user;//用户名
    private String pass;//用户密码
    private int port;//端口

    {
        //默认赋值
        host = "192.168.56.1";
        user = "test2";
        pass = "123";
        port = 21;
    }

    public Client() {
    }

    //全参构造器
    public Client(String host, String user, String pass) {
        this.host = host;
        this.user = user;
        this.pass = pass;

    }

    //取得连接
    public synchronized boolean connect() throws Exception {
        if (socket != null) {
            throw new Exception("already connect!");
        } else {
            System.out.println("Connecting...");
        }
        socket = new Socket(host, port);//创建套接字
        reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
        String response = readLine();
        if (!response.startsWith("220")) {
            //220： 新用户服务准备好了
            throw new Exception("unknown response after connect!");
        } else {
            System.out.println("\nUser service ready");
        }
        sendLine("USER " + user);
        response = readLine();
        if (!response.startsWith("331")) {
            //331： 用户名正确，需要口令
            throw new Exception("unknown response after send user");
        } else {
            System.out.println("User name verified successfully");
        }
        sendLine("PASS " + pass);
        response = readLine();
        if (!response.startsWith("230")) {
            //230： 用户登录
            throw new Exception("unknown response after send pass");
        } else {
            System.out.println("Password verification successful");
        }
        System.out.println("\nLogin!\n");

        //打印FTP客户端及服务器信息
        System.out.println("client info:" + socket.getLocalAddress() + " P:" + socket.getLocalPort());//打印本地服务器地址和本地端口号
        System.out.println("server info:" + socket.getInetAddress() + " P:" + socket.getPort());
        return true;
    }


    /**
     * 向服务器发送指令
     */
    private void sendLine(String line) throws Exception {
        if (socket == null) {
            throw new Exception("not connect!");
        }
        writer.write(line + "\r\n");
        writer.flush();
        if (debug) {
            System.out.println(">" + line);
        }
    }

    /**
     * 接收服务器返回信息
     */
    private String readLine() throws IOException {
        String line = reader.readLine();
        if (debug) {
            System.out.println("<" + line);
        }
        return line;
    }

    /**
     * 返回ftp服务器工作目录
     */
    public synchronized String pwd() throws Exception {
        sendLine("PWD");
        String dir = null;
        String response = readLine();
        if (response.startsWith("257")) {
            //257： 创建"PATHNAME"
            int firstQuote = response.indexOf("/");
            dir = response.substring(firstQuote - 1);
        }
        return dir;
    }

    /**
     * 查看当前目录下的子目录
     */
    public synchronized String dir() throws Exception {
        sendLine("dir");
//        StringBuffer fl = new StringBuffer();
//        String response;
//        do {
//            response = readLine();
//            fl.append(response);
//        }while((response=readLine())!=null);
        String response = readLine();
        return response;
    }


    /**
     * 向服务器发送文件
     * 互斥访问
     */
    public synchronized boolean stor(File file) throws Exception {
        if (file.isDirectory()) {
            throw new Exception("cannot upload a directory!");
        }
        String fileName = file.getName();
        return upload(new FileInputStream(file), fileName);
    }

    /**
     * 上传文件
     */
    public synchronized boolean upload(InputStream inputStream, String fileName) throws Exception {
        BufferedInputStream input = new BufferedInputStream(inputStream);
        sendLine("PASV");
        String response = readLine();
        if (!response.startsWith("227")) {
            //227： 进入被动模式
            throw new Exception("not request passive mode!");
        }
        String ip = null;
        int port = -1;
        int opening = response.indexOf('(');
        int closing = response.indexOf(')', opening + 1);
        if (closing > 0) {
            String dataLink = response.substring(opening + 1, closing);
            StringTokenizer tokenzier = new StringTokenizer(dataLink, ",");
            try {
                ip = tokenzier.nextToken() + "." + tokenzier.nextToken() + "."
                        + tokenzier.nextToken() + "." + tokenzier.nextToken();
                port = Integer.parseInt(tokenzier.nextToken()) * 256 + Integer.parseInt(tokenzier.nextToken());
                ;
            } catch (Exception e) {
                // TODO Auto-generated catch block
                throw new Exception("bad data link after upload!");
            }
        }
        sendLine("STOR " + fileName);
        Socket dataSocket = new Socket(ip, port);
        response = readLine();
        if (!response.startsWith("150")) {
            //150： 打开数据连接
            throw new Exception("not allowed to send the file!");
        }
        BufferedOutputStream output = new BufferedOutputStream(dataSocket.getOutputStream());
        byte[] buffer = new byte[4096];
        int bytesRead = 0;
        while ((bytesRead = input.read(buffer)) != -1) {
            output.write(buffer, 0, bytesRead);
        }
        output.flush();
        output.close();
        input.close();
        response = readLine();
        return response.startsWith("226");
        //226： 关闭数据连接，请求的文件操作成功
    }

}