import java.io.*;
import java.util.Scanner;

/**
 * @Author: Z.Richard
 * @CreateTime: 2020/6/30 8:02
 * @Description:
 **/

public class FTPclient {

    public static void main(String[] args) throws Exception {

        String ip = "192.168.56.1";
        String user = "test2";
        String pass = "123";
        Scanner sc = new Scanner(System.in);

        System.out.println("输入服务器ip：");
        ip = sc.nextLine();
        System.out.println("输入用户名：");
        user = sc.nextLine();
        System.out.println("输入密码：");
        pass = sc.nextLine();

        Client ftp = new Client(ip, user, pass);
        ftp.connect();
        GetUtil gt = new GetUtil();
        menu(ftp, gt);
    }

    public static void menu(Client client, GetUtil getUtil) throws Exception {
        System.out.println("\n\n*************欢迎来到FTP客户端*************");
        while (true) {
            System.out.println("请选择：1.向服务器传递消息 2.展示工作目录");
            System.out.println("       3.向服务器发送文件 4.get 下载文件");
            System.out.println("       5.dir子目录      6.退出系统");

            Scanner sc = new Scanner(System.in);

            int choice = sc.nextInt();
            if (choise1(choice, client, getUtil)) {
                break;
            }
        }
    }

    public static boolean choise1(int cho, Client client, GetUtil getUtil) throws Exception {
        switch (cho) {
            case 1: {
                System.out.println("请输入消息，quit退出");
                getUtil.communication();
            }
            break;
            case 2: {
                String dir = client.pwd();
                System.out.println(dir);
                if (dir.startsWith("\"\\\"")) ;
                System.out.println("当前位于服务器根目录\n\n");
            }
            break;
            case 3: {
                while (true) {
                    System.out.println("请输入文件路径");
                    String dir = new Scanner(System.in).nextLine();
                    File file = new File(dir);
                    if (file.isFile()) {
                        if(client.stor(file)){
                            System.out.println("传输成功！");
                        }else {
                            System.out.println("传输失败！");
                        }
                        break;
                    } else {
                        System.out.println("路径有误");
                    }
                }
            }
            break;
            case 4:{
                System.out.println("默认保存路径为D盘根目录");
                System.out.println("请输入文件完整路径（英文，分隔符需要两个）：");
                String str=new Scanner(System.in).nextLine();
                getUtil.send("get "+str);
                new GetUtil(6789).getMessage();
            }
                break;
            case 5:{
                String str=client.dir();
                if (str.startsWith("500")){
                   System.out.println("该功能暂时出现了bug");
                }
                System.out.println(str);

            }break;
            case 6:{
                System.out.println("退出系统，欢迎下次光临");
                getUtil.send("quit");
                System.exit(0);
            }
            default:
                System.out.println("选择错误请重新选择");
                return false;
        }
        return false;
    }
}
